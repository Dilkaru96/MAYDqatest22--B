import java.time.Duration;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class SeleniumFirst {

    public static void main(String[] args) throws InterruptedException{

        //setting the driver executable
        System.setProperty("webdriver.chrome.driver", ".\\Driver\\chromedriver.exe");

       //Initiating your chromedriver
        WebDriver driver=new ChromeDriver();

        //Applied wait time
        driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);

        //maximize window
        driver.manage().window().maximize();

       //open browser with desried URL
        driver.get("https://qa-challenge.codesubmit.io");

        //Login Account

    driver.findElement(By.id("user-name")).sendKeys("standard_user");
    driver.findElement(By.id("password")).sendKeys("secret_sauce");
    driver.findElement(By.id("login-button")).click();

        driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);

        //Click on Sorting Dropdown
        driver.findElement(By.className("product_sort_container")).click();
        driver.findElement(By.xpath("//*[@id=\"header_container\"]/div[2]/div[2]/span/select/option[4]")).click();


        //Add items to the cart
        driver.findElement(By.id("add-to-cart-sauce-labs-onesie")).click();

        Thread.sleep(4000);

        //Go to the Cart
        driver.findElement(By.id("shopping_cart_container")).click();

        Thread.sleep(4000);


        //Checkout
        driver.findElement(By.id("checkout")).click();

        Thread.sleep(4000);

        //Enter user details
        driver.findElement(By.id("first-name")).sendKeys("Dilshanie");
        driver.findElement(By.id("last-name")).sendKeys("karu");
        driver.findElement(By.id("postal-code")).sendKeys("10204");

        Thread.sleep(4000);

        driver.findElement(By.id("continue")).click();

        Thread.sleep(4000);

        driver.findElement(By.id("finish")).click();

        Thread.sleep(4000);


//closing the browser
        driver.close();

    }

}